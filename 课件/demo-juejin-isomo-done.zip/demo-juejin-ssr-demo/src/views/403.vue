<template>
  <div class="stop">无权限访问</div>
</template>

<style scoped>
.stop {
  padding: 30px;
  text-align: center;
}
</style>