"use strict";
exports.__esModule = true;
var webpack_sources_1 = require("webpack-sources");
var WebpackSizePlugin = /** @class */ (function () {
    function WebpackSizePlugin(options) {
        this.PLUGIN_NAME = 'WebpackSizePlugin';
        this.options = options;
    }
    WebpackSizePlugin.prototype.apply = function (compiler) {
        var _this = this;
        var outputOptions = compiler.options.output;
        compiler.hooks.emit.tap(this.PLUGIN_NAME, function (compilation) {
            var assets = compilation.assets;
            var buildSize = {};
            var files = Object.keys(assets);
            var total = 0;
            for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
                var file = files_1[_i];
                var size = assets[file].size();
                buildSize[file] = size;
                total += size;
            }
            console.log('Build Size: ', buildSize);
            console.log('Total Size: ', total);
            buildSize.total = total;
            assets[outputOptions.publicPath + '/' + (_this.options.fileName || 'build-size.json')] = new webpack_sources_1.RawSource(JSON.stringify(buildSize, null, 4));
        });
    };
    return WebpackSizePlugin;
}());
module.exports = WebpackSizePlugin;
