import { Plugin, Compiler, compilation } from 'webpack';
import { RawSource } from 'webpack-sources';

class WebpackSizePlugin implements Plugin {

    options: any;
    PLUGIN_NAME: string = 'WebpackSizePlugin';

    constructor(options: any) {
        this.options = options;
    }

    apply(compiler: Compiler) {
        const outputOptions = compiler.options.output;
        compiler.hooks.emit.tap(
            this.PLUGIN_NAME,
            compilation => {
                const assets = compilation.assets;
                const buildSize = {} as any;
                const files = Object.keys(assets);
                let total = 0;
                for (let file of files) {
                    const size = assets[file].size();
                    buildSize[file] = size;
                    total += size;
                }
                console.log('Build Size: ', buildSize);
                console.log('Total Size: ', total);
                buildSize.total = total;
                assets[
                    outputOptions.publicPath + '/' + (this.options.fileName || 'build-size.json')
                ] = new RawSource(JSON.stringify(buildSize, null, 4));
            }
        )
    }
}

module.exports = WebpackSizePlugin;