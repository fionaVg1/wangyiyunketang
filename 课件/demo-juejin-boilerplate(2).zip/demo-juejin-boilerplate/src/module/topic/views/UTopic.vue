<template>
  <div></div>
</template>

<script>
export default {
  name: "u-top"
};
</script>