function demo(foo) {
    return foo?.bar?.a?.b?.c;
}