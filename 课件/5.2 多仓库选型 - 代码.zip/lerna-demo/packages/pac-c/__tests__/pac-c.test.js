'use strict';

const pacC = require('..');

describe('pac-c', () => {
    it('needs tests');
});
