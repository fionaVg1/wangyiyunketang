# `pac-c`

> TODO: description

## Usage

```
const pacC = require('pac-c');

// TODO: DEMONSTRATE API
```
