# `pac-b`

> TODO: description

## Usage

```
const pacB = require('pac-b');

// TODO: DEMONSTRATE API
```
