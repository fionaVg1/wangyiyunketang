'use strict';

const pacB = require('..');

describe('pac-b', () => {
    it('needs tests');
});
