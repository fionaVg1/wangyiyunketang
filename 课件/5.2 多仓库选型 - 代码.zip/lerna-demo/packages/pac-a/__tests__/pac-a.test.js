'use strict';

const pacA = require('..');

describe('pac-a', () => {
    it('needs tests');
});
