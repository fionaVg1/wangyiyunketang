# `pac-a`

> TODO: description

## Usage

```
const pacA = require('pac-a');

// TODO: DEMONSTRATE API
```
