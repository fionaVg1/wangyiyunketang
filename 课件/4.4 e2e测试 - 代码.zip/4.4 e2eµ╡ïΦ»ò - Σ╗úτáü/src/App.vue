<template>
  <v-app>
    <ActivitiesList />
  </v-app>
</template>

<script>
import ActivitiesList from './components/ActivitiesList'

export default {
  name: 'App',
  components: {
    ActivitiesList
  },
  data () {
    return {
    }
  },
  computed: {
  },
  methods: {
  }
}
</script>

<style>
</style>
