module.exports = {
  publicPath: './'
};
