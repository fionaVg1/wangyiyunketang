describe('Main Process', () => {
  beforeEach(() => {
    cy.visit('http://localhost:8080');
  });

  it('Make a Todo', () => {
    cy.get('input').first().type('some things');
    cy.get('.v-input__append-outer .v-icon--link').click();
    cy.get('.v-list>div .v-list__tile__content').first().should('have.text', 'some things');
  });

  it('Check a Todo', () => {
    cy.get('input').first().type('some things');
    cy.get('.v-input__append-outer .v-icon--link').click();
    cy.get('.v-input--selection-controls__ripple').first().click();
    cy.get('.v-list>div .v-list__tile__content .v-list__tile__title').first().should('have.class', 'done');
  });

  it('Deleta a Todo', () => {
    cy.get('input').first().type('some things');
    cy.get('.v-input__append-outer .v-icon--link').click();
    cy.get('.v-list .v-list__tile__action .v-icon--link').first().click();
    cy.wait(300);
    cy.get('.v-btn__content').eq(1).click();
    cy.get('.v-list>div').should('have.length', 0);
  });
})
