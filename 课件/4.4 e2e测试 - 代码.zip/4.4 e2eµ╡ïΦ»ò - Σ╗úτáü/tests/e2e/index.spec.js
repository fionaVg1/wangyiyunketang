describe('Main Process', () => {
  it('Make a Todo', () => {
    cy.visit('http://localhost:8080/');
    cy.get('input').first().type('some things');
    cy.get('.v-input__append-outer .v-icon--link').click();
    expect(cy.get('.v-list > div')).to.have.text('some things');
  })
})
