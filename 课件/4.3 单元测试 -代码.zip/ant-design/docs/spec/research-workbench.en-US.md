---
category: Design Patterns (Research)
type: Template Document
order: 2
title: Workbench
skip: true
---
