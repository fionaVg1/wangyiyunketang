---
category: Design Patterns (Research)
type: Template Document
order: 5
title: Exception Page
skip: true
---
