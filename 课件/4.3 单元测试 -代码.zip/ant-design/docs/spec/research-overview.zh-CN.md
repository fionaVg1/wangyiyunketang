---
category: 设计模式 - 探索
order: 0
title: 概览
---

在探索频道中，将公开我们正在研究完善的设计模式和尚未定稿的内容，其中大部分内容可以使用现有的 antd 组件搭建。当然，也可能存在小部分新的组件还未被开发。开辟探索频道，初心是与用户一起完善 Ant Design，如果你正在使用这些内容，你的反馈可以帮助我们更快优化和迭代，并推动组件尽快进入开发状态。
<br/><br/>
[反馈地址](https://www.yuque.com/antdesign/topics) | [阿里内网反馈地址](https://yuque.antfin-inc.com/bigfish/topics)
