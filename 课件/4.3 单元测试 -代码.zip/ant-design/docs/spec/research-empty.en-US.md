---
category: Design Patterns (Research)
type: Global Rules
order: 3
title: Empty Status
skip: true
---

设计模式 - 探索 - 全局规则 - 空状态
