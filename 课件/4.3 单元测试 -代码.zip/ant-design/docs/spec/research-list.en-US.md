---
category: Design Patterns (Research)
type: Template Document
order: 3
title: List Page
skip: true
---
