---
category: Design Patterns (Research)
type: Global Rules
order: 2
title: Message and Feedback
skip: true
---

设计模式 - 探索 - 全局规则 - 消息与反馈
