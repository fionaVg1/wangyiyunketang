---
category: Global Styles
order: 6
title: Shadow
skip: true
---
