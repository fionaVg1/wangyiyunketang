---
category: Design Patterns (Research)
type: Template Document
order: 4
title: Result Page
skip: true
---
