# Form Dom 变化

- 状态 className 现在移动到顶层，不再是 input only
- 去除 `ant-form-item-control-wrapper` 一层 div
- `.has-success` 等状态样式添加 `ant-form-item` 前缀
