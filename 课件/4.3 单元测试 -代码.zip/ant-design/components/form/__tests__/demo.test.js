import demoTest from '../../../tests/shared/demoTest';

demoTest('form', { skip: ['complex-form-control.md'] });
