import demoTest from '../../../tests/shared/demoTest';

demoTest('tree', { skip: ['big-data.md', 'virtual-scroll.md'] });
