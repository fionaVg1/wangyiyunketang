import kuIQ from '../../date-picker/locale/ku_IQ';

export default kuIQ;
