import enGB from '../../date-picker/locale/en_GB';

export default enGB;
