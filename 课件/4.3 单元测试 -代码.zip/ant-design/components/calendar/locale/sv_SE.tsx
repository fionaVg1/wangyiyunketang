import svSE from '../../date-picker/locale/sv_SE';

export default svSE;
