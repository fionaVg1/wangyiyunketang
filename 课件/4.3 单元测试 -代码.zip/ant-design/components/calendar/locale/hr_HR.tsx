import hrHR from '../../date-picker/locale/hr_HR';

export default hrHR;
