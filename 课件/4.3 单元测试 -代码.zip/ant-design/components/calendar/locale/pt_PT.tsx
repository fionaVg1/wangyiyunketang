import ptPT from '../../date-picker/locale/pt_PT';

export default ptPT;
