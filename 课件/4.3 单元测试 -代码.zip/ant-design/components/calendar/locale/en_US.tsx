import enUS from '../../date-picker/locale/en_US';

export default enUS;
