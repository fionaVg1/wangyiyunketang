import ptBR from '../../date-picker/locale/pt_BR';

export default ptBR;
