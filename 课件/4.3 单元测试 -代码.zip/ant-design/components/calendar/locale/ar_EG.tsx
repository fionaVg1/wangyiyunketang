import arEG from '../../date-picker/locale/ar_EG';

export default arEG;
