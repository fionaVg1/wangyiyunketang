import mkMK from '../../date-picker/locale/mk_MK';

export default mkMK;
