import caES from '../../date-picker/locale/ca_ES';

export default caES;
