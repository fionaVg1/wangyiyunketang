import lvLV from '../../date-picker/locale/lv_LV';

export default lvLV;
