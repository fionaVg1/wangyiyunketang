import Trigger from 'rc-trigger/lib/mock';

export default Trigger;
