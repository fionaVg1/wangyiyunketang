function copy(str) {
  copy.lastStr = str;
}

export default copy;
